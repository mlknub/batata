import flet as ft

def main(page):

    def login(e):
        n = nome
        s= senha
        if not n.value:
            nome.error_text= "Entre com um nome"
            page.update()
        if not s.value:
            senha.error_text= "Senha necessária"
            page.update()
        else:
            n = n.value
            s = s.value
            print("Seja bem vindo {}".format(n))
            page.clean()

    nome = ft.TextField(label="Digite o seu nome")
    senha = ft.TextField(label="Digite a sua senha")
    
    page.add(
        nome,
        senha,
        ft.ElevatedButton("Clique em mim", on_click=login)
    )

ft.app(target=main)